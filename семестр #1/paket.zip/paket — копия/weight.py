def kg(el):
    return f'{int(el[:-1])/1000}kg'

def g(el):
    return f'{int(el[:-2])*1000}g'
