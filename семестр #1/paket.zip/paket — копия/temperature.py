def C(el):
    return (el-32)*5/9

def F(el):
    return el*9/5 + 32