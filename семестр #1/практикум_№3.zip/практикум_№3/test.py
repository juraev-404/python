from files import csv_module as cs

cs.load_table('main')

