import csv

def load_table(x):
    with open(f'C:\\Users\\khaiy\\Desktop\\проект\\python\\практикум_№3\\files\\{x}.csv', 'w') as fl:
        return csv.reader(fl)

def print_table(x):
    with open(f'{x}.csv', 'w') as fl:
        lines = fl.readlines
        for i in lines:
            print(i)


def save_table():
    pass

load_table('main')
print_table('main')