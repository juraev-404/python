import csv

def load_table(x):
    with open(f'{x}.csv', 'w') as fl:
        return csv.reader(fl)

def print_table(x):
    with open(f'{x}.csv', 'r') as fl:
        line = csv.reader(fl)
        for i in line:
            print(i)


def save_table():
    pass

# print_table('main')